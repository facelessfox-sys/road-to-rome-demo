extends Node2D

const W := 1672.0
const H := 941.0
const UI_Y := 775.0

var verb: String = "look"
var inventory: Array[String] = []
var selected_item: String = ""
var took_turnip := false
var mars_fed := false
var took_leaf := false
var walking := false
var pending_hotspot := ""
var target := Vector2.ZERO
var walk_clock := 0.0
var ambient_clock := 0.0
var mars_reaction := 0.0
var caption_time := 0.0

var player: Node2D
var player_sprite: Sprite2D
var mars_head: Sprite2D
var hen_brown: Sprite2D
var hen_white: Sprite2D
var objective_label: Label
var caption_label: Label
var verb_border: Panel
var inv_sprites: Array[Sprite2D] = []
var walk_frames: Array[Texture2D] = []
var idle_tex: Texture2D
var talk_tex: Texture2D
var take_tex: Texture2D
var use_tex: Texture2D
var celebrate_tex: Texture2D

var hotspots := {
    "mars": {"rect": Rect2(245, 255, 155, 250), "walk": Vector2(430, 640)},
    "turnip": {"rect": Rect2(245, 525, 85, 80), "walk": Vector2(380, 665)},
    "moonleaf": {"rect": Rect2(420, 560, 100, 100), "walk": Vector2(515, 675)},
    "chicken": {"rect": Rect2(95, 600, 205, 160), "walk": Vector2(330, 700)},
    "well": {"rect": Rect2(945, 420, 265, 270), "walk": Vector2(930, 670)},
    "gate": {"rect": Rect2(1260, 390, 230, 240), "walk": Vector2(1235, 655)},
    "bell": {"rect": Rect2(1490, 95, 135, 180), "walk": Vector2(1320, 625)},
    "sign": {"rect": Rect2(1435, 270, 205, 120), "walk": Vector2(1320, 625)},
    "house": {"rect": Rect2(500, 20, 190, 170), "walk": Vector2(650, 610)}
}

func _ready() -> void:
    get_viewport().set_embedding_subwindows(false)
    _setup_background()
    _load_textures()
    _setup_player()
    _setup_animals()
    _setup_ui()
    _set_objective("Mini-Ziel: Finde einen Weg an Mars Ultor vorbei.")
    _say("Titus", "Rom wartet. Leider wartet Mars Ultor ebenfalls.", 4.0)
    queue_redraw()

func _setup_background() -> void:
    var bg := Sprite2D.new()
    bg.texture = load("res://assets/pretty/hof_showcase.jpg")
    bg.centered = false
    bg.position = Vector2.ZERO
    bg.z_index = -100
    add_child(bg)

func _load_textures() -> void:
    walk_frames = [
        load("res://assets/pretty/titus/w1.webp"),
        load("res://assets/pretty/titus/w2.webp"),
        load("res://assets/pretty/titus/w3.webp"),
        load("res://assets/pretty/titus/w4.webp")
    ]
    idle_tex = load("res://assets/pretty/titus/idle.webp")
    talk_tex = load("res://assets/pretty/titus/talk.webp")
    take_tex = load("res://assets/pretty/titus/take.webp")
    use_tex = load("res://assets/pretty/titus/use.webp")
    celebrate_tex = load("res://assets/pretty/titus/celebrate.webp")

func _setup_player() -> void:
    player = Node2D.new()
    player.position = Vector2(745, 665)
    player.z_index = 45
    add_child(player)

    player_sprite = Sprite2D.new()
    player_sprite.texture = idle_tex
    player_sprite.centered = true
    player.add_child(player_sprite)
    _anchor_player_sprite()
    _scale_player()

func _anchor_player_sprite() -> void:
    if player_sprite.texture == null:
        return
    var h := float(player_sprite.texture.get_height())
    player_sprite.position = Vector2(0, -h * 0.5)

func _setup_animals() -> void:
    mars_head = Sprite2D.new()
    mars_head.texture = load("res://assets/pretty/animals/mars_head.webp")
    mars_head.position = Vector2(321, 367)
    mars_head.z_index = 15
    add_child(mars_head)

    hen_brown = Sprite2D.new()
    hen_brown.texture = load("res://assets/pretty/animals/hen_brown.webp")
    hen_brown.position = Vector2(192, 689)
    hen_brown.z_index = 30
    add_child(hen_brown)

    hen_white = Sprite2D.new()
    hen_white.texture = load("res://assets/pretty/animals/hen_white.webp")
    hen_white.position = Vector2(950, 486)
    hen_white.z_index = 22
    add_child(hen_white)

func _setup_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 100
    add_child(layer)

    objective_label = Label.new()
    objective_label.position = Vector2(24, 20)
    objective_label.size = Vector2(660, 42)
    objective_label.add_theme_font_size_override("font_size", 22)
    objective_label.add_theme_color_override("font_color", Color("#f7dca0"))
    objective_label.add_theme_color_override("font_shadow_color", Color(0,0,0,0.85))
    objective_label.add_theme_constant_override("shadow_offset_x", 2)
    objective_label.add_theme_constant_override("shadow_offset_y", 2)
    layer.add_child(objective_label)

    caption_label = Label.new()
    caption_label.position = Vector2(36, 690)
    caption_label.size = Vector2(1230, 70)
    caption_label.add_theme_font_size_override("font_size", 25)
    caption_label.add_theme_color_override("font_color", Color("#f6e5c2"))
    caption_label.add_theme_color_override("font_shadow_color", Color(0,0,0,0.95))
    caption_label.add_theme_constant_override("shadow_offset_x", 2)
    caption_label.add_theme_constant_override("shadow_offset_y", 2)
    caption_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    layer.add_child(caption_label)

    verb_border = Panel.new()
    verb_border.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(verb_border)
    _update_verb_border()

    for i in range(6):
        var s := Sprite2D.new()
        s.visible = false
        s.z_index = 120
        layer.add_child(s)
        inv_sprites.append(s)

    var hint := Button.new()
    hint.text = "?"
    hint.position = Vector2(1530, 20)
    hint.size = Vector2(48, 42)
    hint.add_theme_font_size_override("font_size", 22)
    hint.pressed.connect(_hint)
    layer.add_child(hint)

    var reset := Button.new()
    reset.text = "↻"
    reset.position = Vector2(1584, 20)
    reset.size = Vector2(48, 42)
    reset.add_theme_font_size_override("font_size", 22)
    reset.pressed.connect(_reset)
    layer.add_child(reset)

func _make_border_style() -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.95, 0.68, 0.24, 0.10)
    style.border_color = Color(1.0, 0.79, 0.37, 0.95)
    style.set_border_width_all(3)
    style.corner_radius_top_left = 8
    style.corner_radius_top_right = 8
    style.corner_radius_bottom_left = 8
    style.corner_radius_bottom_right = 8
    return style

func _update_verb_border() -> void:
    var r := _verb_rect(verb)
    verb_border.position = r.position
    verb_border.size = r.size
    verb_border.add_theme_stylebox_override("panel", _make_border_style())

func _verb_rect(v: String) -> Rect2:
    match v:
        "look":
            return Rect2(250, 785, 120, 100)
        "take":
            return Rect2(378, 785, 132, 100)
        "use":
            return Rect2(520, 785, 136, 100)
        "talk":
            return Rect2(665, 785, 128, 100)
    return Rect2()

func _process(delta: float) -> void:
    ambient_clock += delta
    caption_time = maxf(0.0, caption_time - delta)
    if caption_time <= 0.0 and caption_label.text != "":
        caption_label.text = ""

    _animate_ambient()
    _animate_walk(delta)

    if mars_reaction > 0.0:
        mars_reaction -= delta
        var t := 1.0 - mars_reaction / 1.2
        mars_head.rotation = sin(t * TAU * 1.5) * 0.045
        mars_head.position.x = 321.0 + sin(t * PI) * 16.0
        if mars_reaction <= 0.0:
            mars_head.rotation = 0.0
            mars_head.position = Vector2(321, 367)

func _animate_ambient() -> void:
    mars_head.rotation = sin(ambient_clock * 1.2) * 0.008 if mars_reaction <= 0.0 else mars_head.rotation
    hen_brown.position.y = 689.0 + sin(ambient_clock * 2.2) * 2.3
    hen_brown.rotation = sin(ambient_clock * 1.7) * 0.012
    hen_white.position.y = 486.0 + sin(ambient_clock * 2.6 + 1.4) * 1.8
    hen_white.rotation = sin(ambient_clock * 2.0 + 0.5) * 0.01

func _unhandled_input(event: InputEvent) -> void:
    if not (event is InputEventMouseButton):
        return
    if not event.pressed or event.button_index != MOUSE_BUTTON_LEFT:
        return

    var p: Vector2 = event.position

    if _handle_ui_click(p):
        return

    if p.y >= UI_Y:
        return

    var id := _hotspot_at(p)
    if id != "":
        _walk_to(hotspots[id]["walk"], id)
    else:
        var walk_target := Vector2(clampf(p.x, 300.0, 1325.0), clampf(p.y, 545.0, 720.0))
        _walk_to(walk_target, "")

func _handle_ui_click(p: Vector2) -> bool:
    if _verb_rect("look").has_point(p):
        _set_verb("look")
        return true
    if _verb_rect("take").has_point(p):
        _set_verb("take")
        return true
    if _verb_rect("use").has_point(p):
        _set_verb("use")
        return true
    if _verb_rect("talk").has_point(p):
        _set_verb("talk")
        return true

    var inv_start := 850.0
    var slot_w := 86.0
    for i in range(6):
        var r := Rect2(inv_start + i * slot_w, 790, 78, 92)
        if r.has_point(p):
            if i < inventory.size():
                selected_item = inventory[i]
                _set_verb("use", false)
                _say("Titus", "Benutzen: " + _item_name(selected_item), 2.4)
                _refresh_inventory()
            return true
    return false

func _hotspot_at(p: Vector2) -> String:
    for id in hotspots.keys():
        if hotspots[id]["rect"].has_point(p):
            return id
    return ""

func _walk_to(p: Vector2, action: String) -> void:
    target = p
    pending_hotspot = action
    walking = true
    walk_clock = 0.0
    player_sprite.flip_h = p.x < player.position.x

func _animate_walk(delta: float) -> void:
    if not walking:
        return
    var d := target - player.position
    if d.length() < 7.0:
        player.position = target
        walking = false
        player_sprite.texture = idle_tex
        _anchor_player_sprite()
        _scale_player()
        if pending_hotspot != "":
            var id := pending_hotspot
            pending_hotspot = ""
            _act(id)
        return

    player.position += d.normalized() * minf(310.0 * delta, d.length())
    walk_clock += delta
    player_sprite.texture = walk_frames[int(walk_clock / 0.12) % walk_frames.size()]
    _anchor_player_sprite()
    _scale_player()

func _scale_player() -> void:
    var t: float = clampf((player.position.y - 545.0) / 175.0, 0.0, 1.0)
    var s: float = lerpf(0.72, 1.02, t)
    player.scale = Vector2.ONE * s
    player.z_index = 35 + int(player.position.y / 18.0)

func _set_verb(v: String, clear_item: bool = true) -> void:
    verb = v
    if clear_item:
        selected_item = ""
    _update_verb_border()
    _refresh_inventory()

func _act(id: String) -> void:
    if verb == "look":
        _look(id)
    elif verb == "take":
        _take(id)
    elif verb == "talk":
        _talk(id)
    elif verb == "use":
        _use(id)

func _look(id: String) -> void:
    var text := ""
    match id:
        "mars":
            text = "Mars Ultor. Schrecken der Felder. Vor allem der Rübenfelder."
        "turnip":
            text = "Eine Rübe. Für Menschen Nahrung. Für Mars Ultor: Diplomatie."
        "moonleaf":
            text = "Großmutters Mondblatt. Natürlich wächst es genau dort, wo Mars Wache hält."
        "chicken":
            text = "Die Nachtwache des Hofes. Klein, nervös und vermutlich käuflich."
        "well":
            text = "Ein Brunnen. Tief, kalt und bemerkenswert gleichgültig gegenüber meinen Plänen."
        "gate":
            text = "Hinter diesem Tor beginnt mein Weg nach Rom. Sobald dieser Hof mich endlich gehen lässt."
        "bell":
            text = "Vaters Fuchsglocke. Eine ausgezeichnete Erfindung gegen heimliche Söhne."
        "sign":
            text = "ROMA. Ruhm, Ehre und sicherlich keinerlei unangenehme Überraschungen."
        "house":
            text = "Da drin ist Vater. Er hält Landwirtschaft für eine vollkommen ausreichende Form von Ruhm."
        _:
            text = "Interessant."
    _say("Titus", text, 4.6)

func _take(id: String) -> void:
    if id == "turnip":
        if took_turnip:
            _say("Titus", "Die strategische Rübe befindet sich bereits in meinem Besitz.", 3.0)
            return
        took_turnip = true
        inventory.append("turnip")
        player_sprite.texture = take_tex
        _anchor_player_sprite()
        _say("Titus", "Strategische Reserve.", 2.8)
        _refresh_inventory()
        _set_objective("Mini-Ziel: Füttere Mars Ultor mit der Rübe.")
        return

    if id == "moonleaf":
        if took_leaf:
            _say("Titus", "Ich habe bereits genug Mondblatt.", 2.8)
            return
        if not mars_fed:
            _say("Titus", "Dafür müsste ich an Mars vorbei. Mars hält Abstand für eine persönliche Beleidigung.", 4.2)
            return
        took_leaf = true
        inventory.append("moonleaf")
        player_sprite.texture = celebrate_tex
        _anchor_player_sprite()
        _refresh_inventory()
        _set_objective("Mini-Ziel erfüllt: Mondblatt gesichert.")
        _say("Titus", "Ha! Schritt eins auf dem Weg zur Legion: einen Esel bestechen. Ruhm fühlt sich anders an.", 5.0)
        return

    _say("Titus", "Das passt selbst mit sehr viel Optimismus nicht in meine Tasche.", 3.4)

func _talk(id: String) -> void:
    player_sprite.texture = talk_tex
    _anchor_player_sprite()
    if id == "mars":
        _say("Titus", "Mars, alter Kamerad. Wir zwei gegen die Welt. ...Mars? ...Mars?", 3.8)
    elif id == "chicken":
        _say("Titus", "Kein Wort zu Vater, verstanden?", 2.7)
    else:
        _say("Titus", "Ich fürchte, dieser Gesprächspartner ist eher von der stillen Sorte.", 3.4)

func _use(id: String) -> void:
    if selected_item == "":
        _say("Titus", "Womit denn?", 2.4)
        return

    if selected_item == "turnip" and id == "mars":
        if mars_fed:
            _say("Titus", "Mars hat seine Bestechung bereits erhalten. Ein Mann muss Grenzen setzen.", 3.8)
            return
        mars_fed = true
        mars_reaction = 1.2
        player_sprite.texture = use_tex
        _anchor_player_sprite()
        inventory.erase("turnip")
        selected_item = ""
        _refresh_inventory()
        _set_objective("Mini-Ziel: Jetzt das Mondblatt nehmen.")
        _say("Titus", "Disziplin. Gehorsam. Bestechlichkeit. Fast wie bei der Legion.", 4.5)
        return

    if selected_item == "turnip":
        _say("Titus", "Ich bezweifle, dass die Rübe hier ihre wahre Bestimmung findet.", 3.2)
        return

    if selected_item == "moonleaf":
        _say("Titus", "Das Mondblatt brauche ich für meinen Plan. Nicht verschwenden, Titus.", 3.2)
        return

func _refresh_inventory() -> void:
    for s in inv_sprites:
        s.visible = false

    var inv_start := 889.0
    var slot_w := 86.0
    for i in range(mini(inventory.size(), 6)):
        var id := inventory[i]
        var s := inv_sprites[i]
        s.visible = true
        s.texture = load("res://assets/pretty/items/" + ("turnip_icon.webp" if id == "turnip" else "moonleaf_icon.webp"))
        s.position = Vector2(inv_start + i * slot_w, 836)
        s.scale = Vector2.ONE * 0.38
        s.modulate = Color(1.2, 1.1, 0.92, 1.0) if selected_item == id else Color.WHITE

func _item_name(id: String) -> String:
    return "Rübe" if id == "turnip" else "Mondblatt"

func _set_objective(t: String) -> void:
    objective_label.text = t

func _say(who: String, text: String, seconds: float = 3.6) -> void:
    caption_label.text = who + ": " + text
    caption_time = seconds

func _hint() -> void:
    if not took_turnip:
        _say("Hinweis", "Links beim Stall liegt etwas, das Mars überzeugender findet als militärische Reden.", 5.0)
    elif not mars_fed:
        _say("Hinweis", "Klicke die Rübe im Inventar an und benutze sie anschließend mit Mars Ultor.", 5.0)
    elif not took_leaf:
        _say("Hinweis", "Mars ist beschäftigt. Jetzt kannst du das Mondblatt nehmen.", 5.0)
    else:
        _say("Hinweis", "Geschafft. Für heute darf Titus sich bereits ein bisschen wie ein Held fühlen.", 5.0)

func _reset() -> void:
    verb = "look"
    inventory.clear()
    selected_item = ""
    took_turnip = false
    mars_fed = false
    took_leaf = false
    walking = false
    pending_hotspot = ""
    player.position = Vector2(745, 665)
    player_sprite.flip_h = false
    player_sprite.texture = idle_tex
    _anchor_player_sprite()
    _scale_player()
    mars_head.position = Vector2(321, 367)
    mars_head.rotation = 0.0
    _set_objective("Mini-Ziel: Finde einen Weg an Mars Ultor vorbei.")
    _say("Titus", "Noch einmal. Diesmal mit noch mehr militärischer Präzision.", 3.8)
    _update_verb_border()
    _refresh_inventory()
